//to do


//done
1. ticket table:
    add field for tickt departmemnt
    add field snoozed reason
2. ticket message : 
    add otion for image_url



    //some rules for curd
    1. create new object respone type: 
    {
        error: boolean,
        message: string,
        response:{new object just created}
    }
    

    