const SocketDefine = {
    CREATE_TICKET: "CREATE_TICKET",
    JOIN_TICKET: "JOIN_TICKET",
    CREATE_MESSAGE: "CREATE_MESSAGE",
    RECIEVE_MESSAGE: "RECIEVE_MESSAGE",
    DISCONNECT: "disconnect",
}

module.exports = SocketDefine