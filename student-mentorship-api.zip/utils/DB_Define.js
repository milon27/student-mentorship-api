const DB_Define = {
    //auth
    USERS_TABLE: "users",
    STUDENT_TABLE: "students",
    AO_TABLE: "ao",
    DEPARTMENT_TABLE: "department",
    FACULTY_TABLE: "faculty",
    //support
    TICKET_TABLE: "ticket",
    TICKET_CHAT_TABLE: "ticket_chat",
    //todo
    TODO_TABLE: "todos",
    //notice
    NOTICE_TABLE: "notice"

}
module.exports = DB_Define