const DB_Define = {
    //auth
    USERS_TABLE: "users",
    //support
    TICKET_TABLE: "ticket",
    TICKET_CHAT_TABLE: "ticket_chat",
    //student
    STUDENT_TABLE: "students",
    //ao
    AO_TABLE: "ao",
}
module.exports = DB_Define