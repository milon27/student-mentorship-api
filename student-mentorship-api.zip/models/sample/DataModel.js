/**
 * @design by milon27
 * @sample model
 */

const Model = require("./../Model");

class DataModel extends Model {
    //write your code 
}

module.exports = DataModel